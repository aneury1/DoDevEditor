#define DODEV_PLUGIN_BUILD 1
#include "plugin/DoDevPluginAPI.h"

#include <algorithm>
#include <atomic>
#include <chrono>
#include <cctype>
#include <condition_variable>
#include <cstdint>
#include <cstdlib>
#include <cstring>
#include <fstream>
#include <iomanip>
#include <memory>
#include <mutex>
#include <regex>
#include <sstream>
#include <string>
#include <thread>
#include <vector>

#ifdef _WIN32
#  define NOMINMAX
#  include <winsock2.h>
#  include <ws2tcpip.h>
#  include <windows.h>
using SocketHandle = SOCKET;
static constexpr SocketHandle kInvalidSocket = INVALID_SOCKET;
#else
#  include <arpa/inet.h>
#  include <dlfcn.h>
#  include <errno.h>
#  include <netdb.h>
#  include <sys/socket.h>
#  include <sys/types.h>
#  include <unistd.h>
using SocketHandle = int;
static constexpr SocketHandle kInvalidSocket = -1;
#endif

namespace
{
constexpr uint16_t kDefaultPort = 9934;
constexpr size_t kDefaultMaxTextBytes = 4u * 1024u * 1024u;
constexpr size_t kMaximumRequestHeader = 64u * 1024u;

struct ServerConfig
{
    std::string bindAddress = "0.0.0.0";
    uint16_t port = kDefaultPort;
    std::string authToken;
    size_t maxTextBytes = kDefaultMaxTextBytes;
};

struct EditorSnapshot
{
    bool hasEditor = false;
    std::string title;
    std::string path;
    std::string text;
    size_t caret = 0;
    size_t selectionStart = 0;
    size_t selectionEnd = 0;
    bool truncated = false;
    uint64_t generation = 0;
};

struct State
{
    const DoDevHostApi* host = nullptr;
    std::mutex mutex;
    std::condition_variable changed;
    EditorSnapshot snapshot;
    ServerConfig config;
    std::string configPath;
    std::atomic<bool> stopping{false};
    std::atomic<bool> running{false};
    SocketHandle listener = kInvalidSocket;
    std::thread acceptThread;
    std::mutex clientsMutex;
    std::vector<std::thread> clientThreads;
    DoDevHandle statusPanel = nullptr;
#ifdef _WIN32
    bool winsockInitialized = false;
#endif
};

void ModuleAddressMarker() {}

void CloseSocket(SocketHandle socket)
{
    if (socket == kInvalidSocket)
        return;
#ifdef _WIN32
    closesocket(socket);
#else
    close(socket);
#endif
}

void ShutdownSocket(SocketHandle socket)
{
    if (socket == kInvalidSocket)
        return;
#ifdef _WIN32
    shutdown(socket, SD_BOTH);
#else
    shutdown(socket, SHUT_RDWR);
#endif
}

std::string DirectoryName(const std::string& path)
{
    const size_t slash = path.find_last_of("/\\");
    if (slash == std::string::npos)
        return ".";
    if (slash == 0)
        return path.substr(0, 1);
    return path.substr(0, slash);
}

std::string JoinPath(const std::string& directory, const std::string& name)
{
    if (directory.empty() || directory == ".")
        return directory.empty() ? name : directory + "/" + name;
    const char last = directory.back();
    if (last == '/' || last == '\\')
        return directory + name;
#ifdef _WIN32
    return directory + "\\" + name;
#else
    return directory + "/" + name;
#endif
}

std::string CurrentModulePath()
{
#ifdef _WIN32
    HMODULE module = nullptr;
    if (!GetModuleHandleExA(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS |
                            GET_MODULE_HANDLE_EX_FLAG_UNCHANGED_REFCOUNT,
                            reinterpret_cast<LPCSTR>(&ModuleAddressMarker), &module))
        return {};
    std::vector<char> buffer(4096, 0);
    const DWORD length = GetModuleFileNameA(module, buffer.data(), static_cast<DWORD>(buffer.size()));
    if (length == 0 || length >= buffer.size())
        return {};
    return std::string(buffer.data(), length);
#else
    Dl_info info{};
    if (dladdr(reinterpret_cast<void*>(&ModuleAddressMarker), &info) == 0 || !info.dli_fname)
        return {};
    return info.dli_fname;
#endif
}

void Log(State* state, DoDevLogLevel level, const std::string& message)
{
    if (state && state->host && state->host->log)
        state->host->log(state->host->context, level, message.c_str());
}

std::string ReadHostString(size_t (*reader)(void*, DoDevHandle, char*, size_t),
                           void* context,
                           DoDevHandle handle)
{
    if (!reader || !handle)
        return {};
    const size_t required = reader(context, handle, nullptr, 0);
    if (required == 0)
        return {};
    std::vector<char> buffer(required + 1, 0);
    reader(context, handle, buffer.data(), buffer.size());
    return std::string(buffer.data());
}

std::string ReadTabString(size_t (*reader)(void*, int, char*, size_t),
                          void* context,
                          int index)
{
    if (!reader || index < 0)
        return {};
    const size_t required = reader(context, index, nullptr, 0);
    if (required == 0)
        return {};
    std::vector<char> buffer(required + 1, 0);
    reader(context, index, buffer.data(), buffer.size());
    return std::string(buffer.data());
}

std::string JsonEscape(const std::string& value)
{
    std::ostringstream out;
    for (unsigned char c : value)
    {
        switch (c)
        {
            case '\\': out << "\\\\"; break;
            case '"': out << "\\\""; break;
            case '\b': out << "\\b"; break;
            case '\f': out << "\\f"; break;
            case '\n': out << "\\n"; break;
            case '\r': out << "\\r"; break;
            case '\t': out << "\\t"; break;
            default:
                if (c < 0x20)
                {
                    out << "\\u" << std::hex << std::uppercase << std::setw(4)
                        << std::setfill('0') << static_cast<int>(c)
                        << std::dec << std::nouppercase << std::setfill(' ');
                }
                else
                    out << static_cast<char>(c);
                break;
        }
    }
    return out.str();
}

std::string SnapshotJson(const EditorSnapshot& snapshot)
{
    std::ostringstream out;
    out << "{\"has_editor\":" << (snapshot.hasEditor ? "true" : "false")
        << ",\"generation\":" << snapshot.generation
        << ",\"title\":\"" << JsonEscape(snapshot.title) << "\""
        << ",\"path\":\"" << JsonEscape(snapshot.path) << "\""
        << ",\"caret\":" << snapshot.caret
        << ",\"selection\":{\"start\":" << snapshot.selectionStart
        << ",\"end\":" << snapshot.selectionEnd << "}"
        << ",\"truncated\":" << (snapshot.truncated ? "true" : "false")
        << ",\"text\":\"" << JsonEscape(snapshot.text) << "\"}";
    return out.str();
}

void UpdateSnapshot(State* state)
{
    if (!state || !state->host)
        return;

    EditorSnapshot next;
    const DoDevHostApi* host = state->host;
    DoDevHandle editor = host->active_editor ? host->active_editor(host->context) : nullptr;
    if (editor && (!host->is_editor || host->is_editor(host->context, editor)))
    {
        next.hasEditor = true;
        next.path = ReadHostString(host->editor_get_path, host->context, editor);
        const int tabIndex = host->active_tab_index ? host->active_tab_index(host->context) : -1;
        next.title = ReadTabString(host->tab_title, host->context, tabIndex);
        next.caret = host->editor_get_caret ? host->editor_get_caret(host->context, editor) : 0;
        if (host->editor_get_selection)
            host->editor_get_selection(host->context, editor, &next.selectionStart, &next.selectionEnd);

        if (host->editor_get_text)
        {
            const size_t required = host->editor_get_text(host->context, editor, nullptr, 0);
            if (required > 0)
            {
                const size_t maxBytes = std::max<size_t>(1, state->config.maxTextBytes);
                const size_t capacity = std::min(required + 1, maxBytes + 1);
                std::vector<char> buffer(capacity, 0);
                host->editor_get_text(host->context, editor, buffer.data(), buffer.size());
                size_t textLength = 0;
                while (textLength < buffer.size() && buffer[textLength] != '\0')
                    ++textLength;
                next.text.assign(buffer.data(), textLength);
                next.truncated = required > (maxBytes + 1);
            }
        }
    }

    {
        std::lock_guard<std::mutex> lock(state->mutex);
        next.generation = state->snapshot.generation + 1;
        state->snapshot = std::move(next);
    }
    state->changed.notify_all();
}

std::string ReadFile(const std::string& path)
{
    std::ifstream input(path, std::ios::binary);
    if (!input)
        return {};
    std::ostringstream out;
    out << input.rdbuf();
    return out.str();
}

void WriteDefaultConfig(const std::string& path)
{
    std::ifstream existing(path, std::ios::binary);
    if (existing.good())
        return;
    std::ofstream output(path, std::ios::binary | std::ios::trunc);
    if (!output)
        return;
    output << "{\n"
              "  \"bind_address\": \"0.0.0.0\",\n"
              "  \"port\": 9934,\n"
              "  \"auth_token\": \"\",\n"
              "  \"max_text_bytes\": 4194304\n"
              "}\n";
}

bool RegexString(const std::string& text, const char* key, std::string* value)
{
    const std::regex pattern(std::string("\\\"") + key + "\\\"\\s*:\\s*\\\"([^\\\"]*)\\\"");
    std::smatch match;
    if (!std::regex_search(text, match, pattern) || match.size() < 2)
        return false;
    *value = match[1].str();
    return true;
}

bool RegexUnsigned(const std::string& text, const char* key, uint64_t* value)
{
    const std::regex pattern(std::string("\\\"") + key + "\\\"\\s*:\\s*([0-9]+)");
    std::smatch match;
    if (!std::regex_search(text, match, pattern) || match.size() < 2)
        return false;
    try
    {
        *value = std::stoull(match[1].str());
        return true;
    }
    catch (...)
    {
        return false;
    }
}

ServerConfig LoadConfig(State* state)
{
    ServerConfig config;
    WriteDefaultConfig(state->configPath);
    const std::string text = ReadFile(state->configPath);
    std::string value;
    uint64_t number = 0;
    if (RegexString(text, "bind_address", &value) && !value.empty())
        config.bindAddress = value;
    if (RegexUnsigned(text, "port", &number) && number > 0 && number <= 65535)
        config.port = static_cast<uint16_t>(number);
    if (RegexString(text, "auth_token", &value))
        config.authToken = value;
    if (RegexUnsigned(text, "max_text_bytes", &number) && number > 0)
        config.maxTextBytes = static_cast<size_t>(std::min<uint64_t>(number, 256ull * 1024ull * 1024ull));

    if (const char* env = std::getenv("DODEV_HTTP_BIND"))
        if (*env) config.bindAddress = env;
    if (const char* env = std::getenv("DODEV_HTTP_PORT"))
    {
        try
        {
            const unsigned long port = std::stoul(env);
            if (port > 0 && port <= 65535)
                config.port = static_cast<uint16_t>(port);
        }
        catch (...) {}
    }
    if (const char* env = std::getenv("DODEV_HTTP_TOKEN"))
        config.authToken = env;
    if (const char* env = std::getenv("DODEV_HTTP_MAX_TEXT_BYTES"))
    {
        try
        {
            const unsigned long long bytes = std::stoull(env);
            if (bytes > 0)
                config.maxTextBytes = static_cast<size_t>(std::min<unsigned long long>(bytes, 256ull * 1024ull * 1024ull));
        }
        catch (...) {}
    }
    return config;
}

bool SendAll(SocketHandle socket, const std::string& data)
{
    size_t sent = 0;
    while (sent < data.size())
    {
#ifdef _WIN32
        const int chunk = send(socket, data.data() + sent,
                               static_cast<int>(std::min<size_t>(data.size() - sent, 1u << 20)), 0);
#else
        const ssize_t chunk = send(socket, data.data() + sent, data.size() - sent,
#  ifdef MSG_NOSIGNAL
                                   MSG_NOSIGNAL
#  else
                                   0
#  endif
        );
#endif
        if (chunk <= 0)
            return false;
        sent += static_cast<size_t>(chunk);
    }
    return true;
}

std::string Lower(std::string value)
{
    std::transform(value.begin(), value.end(), value.begin(), [](unsigned char c) {
        return static_cast<char>(std::tolower(c));
    });
    return value;
}

struct HttpRequest
{
    std::string method;
    std::string path;
    std::string headersLower;
};

bool ReceiveRequest(SocketHandle socket, HttpRequest* request)
{
    std::string data;
    data.reserve(4096);
    char buffer[4096];
    while (data.size() < kMaximumRequestHeader)
    {
#ifdef _WIN32
        const int count = recv(socket, buffer, sizeof(buffer), 0);
#else
        const ssize_t count = recv(socket, buffer, sizeof(buffer), 0);
#endif
        if (count <= 0)
            return false;
        data.append(buffer, static_cast<size_t>(count));
        if (data.find("\r\n\r\n") != std::string::npos)
            break;
    }
    const size_t end = data.find("\r\n\r\n");
    if (end == std::string::npos)
        return false;
    const size_t firstLineEnd = data.find("\r\n");
    if (firstLineEnd == std::string::npos)
        return false;
    std::istringstream firstLine(data.substr(0, firstLineEnd));
    std::string version;
    firstLine >> request->method >> request->path >> version;
    request->headersLower = Lower(data.substr(firstLineEnd + 2, end - firstLineEnd - 2));
    return !request->method.empty() && !request->path.empty();
}

bool Authorized(const ServerConfig& config, const HttpRequest& request)
{
    if (config.authToken.empty())
        return true;
    const std::string tokenLower = Lower(config.authToken);
    const std::string bearer = "authorization: bearer " + tokenLower;
    const std::string custom = "x-dodev-token: " + tokenLower;
    return request.headersLower.find(bearer) != std::string::npos ||
           request.headersLower.find(custom) != std::string::npos;
}

void SendSimple(SocketHandle socket,
                int status,
                const char* reason,
                const char* contentType,
                const std::string& body)
{
    std::ostringstream response;
    response << "HTTP/1.1 " << status << ' ' << reason << "\r\n"
             << "Content-Type: " << contentType << "\r\n"
             << "Content-Length: " << body.size() << "\r\n"
             << "Cache-Control: no-store\r\n"
             << "Connection: close\r\n"
             << "Access-Control-Allow-Origin: *\r\n\r\n"
             << body;
    SendAll(socket, response.str());
}

EditorSnapshot CopySnapshot(State* state)
{
    std::lock_guard<std::mutex> lock(state->mutex);
    return state->snapshot;
}

void StreamEditor(State* state, SocketHandle socket)
{
    const std::string header =
        "HTTP/1.1 200 OK\r\n"
        "Content-Type: text/event-stream; charset=utf-8\r\n"
        "Cache-Control: no-cache\r\n"
        "Connection: keep-alive\r\n"
        "Access-Control-Allow-Origin: *\r\n"
        "X-Accel-Buffering: no\r\n\r\n";
    if (!SendAll(socket, header))
        return;

    uint64_t lastGeneration = 0;
    while (!state->stopping.load())
    {
        EditorSnapshot snapshot;
        {
            std::unique_lock<std::mutex> lock(state->mutex);
            if (lastGeneration == 0)
                snapshot = state->snapshot;
            else
            {
                state->changed.wait_for(lock, std::chrono::seconds(15), [&] {
                    return state->stopping.load() || state->snapshot.generation != lastGeneration;
                });
                if (state->stopping.load())
                    break;
                if (state->snapshot.generation == lastGeneration)
                {
                    lock.unlock();
                    if (!SendAll(socket, ": keep-alive\n\n"))
                        break;
                    continue;
                }
                snapshot = state->snapshot;
            }
        }

        lastGeneration = snapshot.generation;
        const std::string event = "event: editor\nid: " + std::to_string(snapshot.generation) +
                                  "\ndata: " + SnapshotJson(snapshot) + "\n\n";
        if (!SendAll(socket, event))
            break;
    }
}

void SetSocketTimeouts(SocketHandle socket)
{
#ifdef _WIN32
    DWORD millis = 5000;
    setsockopt(socket, SOL_SOCKET, SO_RCVTIMEO, reinterpret_cast<const char*>(&millis), sizeof(millis));
    setsockopt(socket, SOL_SOCKET, SO_SNDTIMEO, reinterpret_cast<const char*>(&millis), sizeof(millis));
#else
    timeval timeout{};
    timeout.tv_sec = 5;
    setsockopt(socket, SOL_SOCKET, SO_RCVTIMEO, &timeout, sizeof(timeout));
    setsockopt(socket, SOL_SOCKET, SO_SNDTIMEO, &timeout, sizeof(timeout));
#endif
}

void HandleClient(State* state, SocketHandle client)
{
    SetSocketTimeouts(client);
    HttpRequest request;
    if (!ReceiveRequest(client, &request))
    {
        CloseSocket(client);
        return;
    }

    ServerConfig config;
    {
        std::lock_guard<std::mutex> lock(state->mutex);
        config = state->config;
    }
    if (!Authorized(config, request))
    {
        SendSimple(client, 401, "Unauthorized", "application/json; charset=utf-8",
                   "{\"error\":\"unauthorized\"}\n");
        CloseSocket(client);
        return;
    }

    if (request.method == "OPTIONS")
    {
        const std::string response =
            "HTTP/1.1 204 No Content\r\n"
            "Access-Control-Allow-Origin: *\r\n"
            "Access-Control-Allow-Methods: GET, POST, OPTIONS\r\n"
            "Access-Control-Allow-Headers: Authorization, Content-Type, X-DoDev-Token\r\n"
            "Content-Length: 0\r\nConnection: close\r\n\r\n";
        SendAll(client, response);
    }
    else if (request.method == "GET" && request.path == "/health")
    {
        const EditorSnapshot snapshot = CopySnapshot(state);
        const std::string body = std::string("{\"ok\":true,\"service\":\"dodev-http-editor-server\",\"generation\":") +
                                 std::to_string(snapshot.generation) + "}\n";
        SendSimple(client, 200, "OK", "application/json; charset=utf-8", body);
    }
    else if (request.method == "POST" && request.path == "/api/editor/snapshot")
    {
        SendSimple(client, 200, "OK", "application/json; charset=utf-8", SnapshotJson(CopySnapshot(state)) + "\n");
    }
    else if ((request.method == "POST" || request.method == "GET") &&
             request.path == "/api/editor/stream")
    {
        StreamEditor(state, client);
    }
    else
    {
        SendSimple(client, 404, "Not Found", "application/json; charset=utf-8",
                   "{\"error\":\"not_found\"}\n");
    }
    ShutdownSocket(client);
    CloseSocket(client);
}

SocketHandle CreateListener(const ServerConfig& config, std::string* error)
{
    addrinfo hints{};
    hints.ai_family = AF_UNSPEC;
    hints.ai_socktype = SOCK_STREAM;
    hints.ai_protocol = IPPROTO_TCP;
    hints.ai_flags = AI_PASSIVE;

    addrinfo* results = nullptr;
    const std::string port = std::to_string(config.port);
    const int rc = getaddrinfo(config.bindAddress.empty() ? nullptr : config.bindAddress.c_str(),
                               port.c_str(), &hints, &results);
    if (rc != 0)
    {
#ifdef _WIN32
        *error = "getaddrinfo failed: " + std::to_string(rc);
#else
        *error = std::string("getaddrinfo failed: ") + gai_strerror(rc);
#endif
        return kInvalidSocket;
    }

    SocketHandle listener = kInvalidSocket;
    for (addrinfo* ai = results; ai; ai = ai->ai_next)
    {
        SocketHandle candidate = socket(ai->ai_family, ai->ai_socktype, ai->ai_protocol);
        if (candidate == kInvalidSocket)
            continue;
        int reuse = 1;
#ifdef _WIN32
        setsockopt(candidate, SOL_SOCKET, SO_REUSEADDR,
                   reinterpret_cast<const char*>(&reuse), sizeof(reuse));
#else
        setsockopt(candidate, SOL_SOCKET, SO_REUSEADDR, &reuse, sizeof(reuse));
#endif
#ifdef _WIN32
        const int addressLength = static_cast<int>(ai->ai_addrlen);
#else
        const socklen_t addressLength = static_cast<socklen_t>(ai->ai_addrlen);
#endif
        if (bind(candidate, ai->ai_addr, addressLength) == 0 &&
            listen(candidate, 16) == 0)
        {
            listener = candidate;
            break;
        }
        CloseSocket(candidate);
    }
    freeaddrinfo(results);
    if (listener == kInvalidSocket)
        *error = "could not bind/listen on " + config.bindAddress + ":" + std::to_string(config.port);
    return listener;
}

void AcceptLoop(State* state)
{
    while (!state->stopping.load())
    {
        sockaddr_storage peer{};
#ifdef _WIN32
        int peerLength = sizeof(peer);
#else
        socklen_t peerLength = sizeof(peer);
#endif
        SocketHandle client = accept(state->listener, reinterpret_cast<sockaddr*>(&peer), &peerLength);
        if (client == kInvalidSocket)
        {
            if (state->stopping.load())
                break;
            std::this_thread::sleep_for(std::chrono::milliseconds(50));
            continue;
        }
        std::lock_guard<std::mutex> lock(state->clientsMutex);
        state->clientThreads.emplace_back([state, client] { HandleClient(state, client); });
    }
}

bool StartServer(State* state)
{
    if (!state || state->running.load())
        return true;

#ifdef _WIN32
    if (!state->winsockInitialized)
    {
        WSADATA data{};
        if (WSAStartup(MAKEWORD(2, 2), &data) != 0)
        {
            Log(state, DODEV_LOG_ERROR, "HTTP Editor Server: WSAStartup failed");
            return false;
        }
        state->winsockInitialized = true;
    }
#endif

    const ServerConfig loaded = LoadConfig(state);
    {
        std::lock_guard<std::mutex> lock(state->mutex);
        state->config = loaded;
    }
    UpdateSnapshot(state);

    std::string error;
    state->listener = CreateListener(loaded, &error);
    if (state->listener == kInvalidSocket)
    {
        Log(state, DODEV_LOG_ERROR, "HTTP Editor Server: " + error);
        if (state->host && state->host->set_status)
            state->host->set_status(state->host->context, ("HTTP Editor Server: " + error).c_str());
        return false;
    }

    state->stopping.store(false);
    state->running.store(true);
    state->acceptThread = std::thread([state] { AcceptLoop(state); });
    const std::string address = loaded.bindAddress + ":" + std::to_string(loaded.port);
    Log(state, DODEV_LOG_INFO, "HTTP Editor Server listening on " + address);
    if (loaded.bindAddress == "0.0.0.0" && loaded.authToken.empty())
        Log(state, DODEV_LOG_WARNING,
            "HTTP Editor Server is exposed on all interfaces without an auth_token; editor contents are readable by reachable clients.");
    if (state->host && state->host->set_status)
        state->host->set_status(state->host->context, ("HTTP Editor Server listening on " + address).c_str());
    return true;
}

void StopServer(State* state)
{
    if (!state || !state->running.exchange(false))
        return;
    state->stopping.store(true);
    state->changed.notify_all();
    ShutdownSocket(state->listener);
    CloseSocket(state->listener);
    state->listener = kInvalidSocket;
    if (state->acceptThread.joinable())
        state->acceptThread.join();

    std::vector<std::thread> clients;
    {
        std::lock_guard<std::mutex> lock(state->clientsMutex);
        clients.swap(state->clientThreads);
    }
    for (std::thread& thread : clients)
        if (thread.joinable()) thread.join();

#ifdef _WIN32
    if (state->winsockInitialized)
    {
        WSACleanup();
        state->winsockInitialized = false;
    }
#endif
    Log(state, DODEV_LOG_INFO, "HTTP Editor Server stopped");
}

std::string StatusText(State* state)
{
    ServerConfig config;
    EditorSnapshot snapshot;
    {
        std::lock_guard<std::mutex> lock(state->mutex);
        config = state->config;
        snapshot = state->snapshot;
    }
    std::ostringstream out;
    out << "HTTP EDITOR SERVER\n\n"
        << "State: " << (state->running.load() ? "RUNNING" : "STOPPED") << '\n'
        << "Bind: " << config.bindAddress << '\n'
        << "Port: " << config.port << '\n'
        << "Authentication: " << (config.authToken.empty() ? "none" : "token required") << '\n'
        << "Max editor text: " << config.maxTextBytes << " bytes\n"
        << "Config: " << state->configPath << "\n\n"
        << "POST /api/editor/snapshot\n"
        << "POST /api/editor/stream   (SSE)\n"
        << "GET  /health\n\n"
        << "Active editor: " << (snapshot.hasEditor ? "yes" : "no") << '\n'
        << "Title: " << snapshot.title << '\n'
        << "Path: " << snapshot.path << '\n'
        << "Generation: " << snapshot.generation << '\n'
        << "Text bytes cached: " << snapshot.text.size()
        << (snapshot.truncated ? " (truncated)" : "") << '\n';
    return out.str();
}

void ShowStatus(void* userData)
{
    auto* state = static_cast<State*>(userData);
    if (!state || !state->host)
        return;
    const std::string text = StatusText(state);
    if (!state->statusPanel && state->host->create_text_panel)
        state->statusPanel = state->host->create_text_panel(state->host->context,
                                                             DODEV_PANEL_LOCATION_SIDE,
                                                             "HTTP SERVER",
                                                             text.c_str(), 1);
    else if (state->statusPanel && state->host->text_panel_set_text)
        state->host->text_panel_set_text(state->host->context, state->statusPanel, text.c_str());
}

void StartMenu(void* userData)
{
    auto* state = static_cast<State*>(userData);
    StartServer(state);
    ShowStatus(state);
}

void StopMenu(void* userData)
{
    auto* state = static_cast<State*>(userData);
    StopServer(state);
    ShowStatus(state);
}

void ReloadConfigMenu(void* userData)
{
    auto* state = static_cast<State*>(userData);
    if (!state)
        return;
    const bool wasRunning = state->running.load();
    if (wasRunning)
        StopServer(state);
    {
        std::lock_guard<std::mutex> lock(state->mutex);
        state->config = LoadConfig(state);
    }
    if (wasRunning)
        StartServer(state);
    else
        UpdateSnapshot(state);
    ShowStatus(state);
}
}

extern "C" DODEV_PLUGIN_EXPORT int dodev_plugin_load(const DoDevHostApi* host,
                                                       DoDevPluginInfo* info,
                                                       void** pluginState)
{
    if (!host || host->abi_version != DODEV_PLUGIN_ABI_VERSION || !info || !pluginState)
        return 0;

    auto state = std::make_unique<State>();
    state->host = host;
    const std::string module = CurrentModulePath();
    state->configPath = JoinPath(DirectoryName(module.empty() ? "." : module),
                                 "dodev_http_editor_server.json");
    state->config = LoadConfig(state.get());

    info->abi_version = DODEV_PLUGIN_ABI_VERSION;
    info->size = sizeof(*info);
    info->id = "org.dodev.http-editor-server";
    info->name = "HTTP Editor Server";
    info->version = "1.0.0";
    info->description = "Streams the active DoDevEditor source editor over a configurable HTTP server.";

    if (host->add_menu_item)
    {
        host->add_menu_item(host->context, "Plugins", "HTTP Editor Server: Status", "", &ShowStatus, state.get());
        host->add_menu_item(host->context, "Plugins", "HTTP Editor Server: Start", "", &StartMenu, state.get());
        host->add_menu_item(host->context, "Plugins", "HTTP Editor Server: Stop", "", &StopMenu, state.get());
        host->add_menu_item(host->context, "Plugins", "HTTP Editor Server: Reload Config", "", &ReloadConfigMenu, state.get());
    }

    UpdateSnapshot(state.get());
    StartServer(state.get());
    *pluginState = state.release();
    return 1;
}

extern "C" DODEV_PLUGIN_EXPORT void dodev_plugin_unload(void* pluginState)
{
    std::unique_ptr<State> state(static_cast<State*>(pluginState));
    if (!state)
        return;
    StopServer(state.get());
}

extern "C" DODEV_PLUGIN_EXPORT void dodev_plugin_on_event(void* pluginState,
                                                            const DoDevEvent* event)
{
    auto* state = static_cast<State*>(pluginState);
    if (!state || !event)
        return;
    switch (event->type)
    {
        case DODEV_EVENT_ACTIVE_TAB_CHANGED:
        case DODEV_EVENT_EDITOR_OPENED:
        case DODEV_EVENT_EDITOR_CLOSED:
        case DODEV_EVENT_EDITOR_CHANGED:
            UpdateSnapshot(state);
            break;
        case DODEV_EVENT_WORKSPACE_CHANGED:
        default:
            break;
    }
}
