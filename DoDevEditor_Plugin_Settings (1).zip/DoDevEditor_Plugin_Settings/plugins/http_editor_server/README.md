# HTTP Editor Server Plugin

This standalone DoDevEditor plugin exposes the current active source editor over HTTP.
It uses only the public `DoDevPluginAPI.h` ABI and does not link wxWidgets.

## Default network configuration

On first load the plugin creates `dodev_http_editor_server.json` beside the plugin:

```json
{
  "bind_address": "0.0.0.0",
  "port": 9934,
  "auth_token": "",
  "max_text_bytes": 4194304
}
```

`0.0.0.0` exposes the service on every network interface. Set `bind_address` to
`127.0.0.1` if only local access is required. Set `auth_token` to require either:

- `Authorization: Bearer <token>`
- `X-DoDev-Token: <token>`

Environment variables override the JSON file:

- `DODEV_HTTP_BIND`
- `DODEV_HTTP_PORT`
- `DODEV_HTTP_TOKEN`
- `DODEV_HTTP_MAX_TEXT_BYTES`

Use **Plugins > HTTP Editor Server: Reload Config** after editing the file.

## API

### Health

```bash
curl http://127.0.0.1:9934/health
```

### One active-editor snapshot

```bash
curl -X POST http://127.0.0.1:9934/api/editor/snapshot
```

Response contains active tab title/path, caret, selection, complete editor text up to
`max_text_bytes`, a truncation flag, and the current generation counter.

### Live editor stream

```bash
curl -N -X POST http://127.0.0.1:9934/api/editor/stream
```

The connection stays open as an SSE stream. An `editor` event is sent immediately,
and another is sent whenever the active editor changes, the active tab changes, or an
editor is opened/closed. Keep-alive comments are emitted while idle.

The server thread never calls wxWidgets controls. Editor data is captured on the
DoDevEditor event/UI thread and copied into a mutex-protected snapshot used by HTTP
worker threads.

## Standalone build

Linux:

```bash
cmake -S plugins/http_editor_server -B build/http-editor-server \
  -DDODEV_SDK_ROOT="$PWD"
cmake --build build/http-editor-server
```

Windows can build the same CMake project with MSVC or MinGW. Copy the generated
`.so`/`.dll` into the `plugins` directory beside DoDevEditor.

## DoDevEditor General Settings integration

When this plugin is loaded by the bundled DoDevEditor host, **General Settings ->
Plugins** can set the plugin directory, bind address, port, authentication token,
and maximum editor-text size. The host passes those values through
`DODEV_HTTP_BIND`, `DODEV_HTTP_PORT`, `DODEV_HTTP_TOKEN`, and
`DODEV_HTTP_MAX_TEXT_BYTES`, which intentionally take precedence over this
plugin's adjacent JSON configuration. Saving editor settings reloads plugins so
new HTTP values take effect.
